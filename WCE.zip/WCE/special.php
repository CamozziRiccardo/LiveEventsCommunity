<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['ID_user'] !== 1) {
    header("Location: login.php");
    exit();
}

require 'db.php';

function getPendingEvents($conn) {
    $stmt = $conn->prepare("SELECT * FROM wce_eventi WHERE approvazione = false");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

try {
    $events = getPendingEvents($conn);
} catch (PDOException $e) {
    $error = "Errore del database: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Pagina Speciale</title>
</head>
<body>
    <?php include 'assets/header.php'; ?>

    <div class="container mt-4">
        <h1>Eventi in attesa di approvazione</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($events)): ?>
            <?php foreach ($events as $event): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($event['titolo']); ?></h5>
                        <p class="card-text">Categoria: <?php echo htmlspecialchars($event['ID_categoria']); ?></p>
                        <p class="card-text">Luogo: <?php echo htmlspecialchars($event['ID_luogo']); ?></p>
                        <p class="card-text">Data: <?php echo htmlspecialchars($event['data']); ?></p>
                        <p class="card-text">Descrizione: <?php echo nl2br(htmlspecialchars($event['descrizione'])); ?></p>
                        <form method="POST" action="special.php">
                            <input type="hidden" name="event_id" value="<?php echo htmlspecialchars($event['ID_evento']); ?>">
                            <button type="submit" name="action" value="approve" class="btn btn-success">Approva</button>
                            <button type="submit" name="action" value="reject" class="btn btn-danger">Rifiuta</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Nessun evento in attesa di approvazione.</p>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
