<?php
session_start();

function handleRegister($conn) {
    $nome = $_POST['nome'] ?? null;
    $cognome = $_POST['cognome'] ?? null;
    $nickname = $_POST['nickname'] ?? null;
    $email = $_POST['email'] ?? null;
    $password = $_POST['password'] ?? null;
    $residenza = $_POST['residenza'] ?? null;

    if ($nome && $cognome && $nickname && $email && $password && $residenza) {
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM wce_utenti WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn() > 0) {
                header("Location: register.php?error=email_gia_in_uso");
                exit();
            }

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO wce_utenti (nome, cognome, nickname, email, password, residenza) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nome, $cognome, $nickname, $email, $hashedPassword, $residenza]);

            header("Location: login.php?status=registrato");
            exit();
        } catch (PDOException $e) {
            header("Location: register.php?error=errore_db");
            exit();
        }
    } else {
        header("Location: register.php?error=campi_mancanti");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require 'db.php';
    handleRegister($conn);
}

$error = $_GET['error'] ?? null;
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Registrazione - Live Events Community</title>
</head>
<body>
    <?php include 'assets/header.php'; ?>

    <div class="container mt-4">
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?php
                if ($error === 'email_gia_in_uso') {
                    echo 'Questa email è già registrata.';
                } elseif ($error === 'errore_db') {
                    echo 'Si è verificato un errore nel database. Riprova più tardi.';
                } elseif ($error === 'campi_mancanti') {
                    echo 'Per favore, compila tutti i campi.';
                } else {
                    echo htmlspecialchars(urldecode($error));
                }
                ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Registrati</h5>
                <form method="POST" action="register.php">
                    <div class="form-group">
                        <label for="nome">Nome</label>
                        <input type="text" class="form-control" id="nome" name="nome" required>
                    </div>
                    <div class="form-group">
                        <label for="cognome">Cognome</label>
                        <input type="text" class="form-control" id="cognome" name="cognome" required>
                    </div>
                    <div class="form-group">
                        <label for="nickname">Nickname</label>
                        <input type="text" class="form-control" id="nickname" name="nickname" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Indirizzo email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="password" name="password" required>
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                    <i class="fa fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="residenza">Residenza</label>
                        <select class="form-control" id="residenza" name="residenza" required>
                            <option value="">Seleziona la tua provincia</option>
                            <?php
                            try {
                                require 'db.php';
                                $stmt = $conn->prepare("SELECT ID_luogo, nome, sigla FROM wce_luogo");
                                $stmt->execute();
                                $regions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($regions as $region) {
                                    echo '<option value="' . htmlspecialchars($region['ID_luogo']) . '">' . htmlspecialchars($region['nome']) . '</option>';
                                }
                            } catch (PDOException $e) {
                                echo '<option value="">Errore nel caricamento delle province</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Registrati</button>
                </form>
                <p class="mt-3">Sei già registrato? <a href="login.php">Accedi qui</a></p>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.getElementById('togglePassword').addEventListener('click', function () {
            var passwordField = document.getElementById('password');
            var passwordFieldType = passwordField.getAttribute('type');
            if (passwordFieldType === 'password') {
                passwordField.setAttribute('type', 'text');
                this.innerHTML = '<i class="fa fa-eye-slash"></i>';
            } else {
                passwordField.setAttribute('type', 'password');
                this.innerHTML = '<i class="fa fa-eye"></i>';
            }
        });
    </script>
</body>
</html>
