<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

function getEventDetails($conn, $eventId) {
    $stmt = $conn->prepare("SELECT titolo, descrizione, data, ID_luogo, ID_categoria, 
                                    (SELECT nome FROM wce_luogo WHERE ID_luogo = wce_eventi.ID_luogo) AS luogo_nome,
                                    (SELECT nome_cat FROM wce_categoria WHERE ID_categoria = wce_eventi.ID_categoria) AS categoria_nome,
                                    indirizzo
                             FROM wce_eventi WHERE ID_evento = ?");
    $stmt->execute([$eventId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getEventComments($conn, $eventId) {
    $stmt = $conn->prepare("SELECT testo, nickname FROM wce_commento JOIN wce_utenti ON wce_commento.ID_user = wce_utenti.ID_user WHERE wce_commento.ID_evento = ?");
    $stmt->execute([$eventId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function handleComment($conn) {
    $eventId = $_POST['event_id'] ?? null;
    $commentText = $_POST['commentText'] ?? null;

    if (isset($_SESSION['user'])) {
        if (empty(trim($commentText))) {
            header("Location: view_event.php?event_id=$eventId&error=commento_vuoto");
            exit();
        }

        $userId = $_SESSION['user']['ID_user'];
        $stmt = $conn->prepare("INSERT INTO wce_commento (ID_evento, ID_user, testo, data) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$eventId, $userId, $commentText]);

        header("Location: view_event.php?event_id=$eventId");
        exit();
    } else {
        header("Location: view_event.php?event_id=$eventId&error=non_autenticato");
        exit();
    }
}

function handleParticipation($conn) {
    if (!isset($_SESSION['user'])) {
        header('Location: view_event.php?event_id=' . $_POST['event_id'] . '&error=non_autenticato');
        exit();
    }

    $userId = $_SESSION['user']['ID_user'] ?? null;
    $eventId = $_POST['event_id'] ?? null;
    $action = $_POST['action'] ?? null;

    if ($userId && $eventId) {
        try {
            $stmt = $conn->prepare("SELECT data FROM wce_eventi WHERE ID_evento = ?");
            $stmt->execute([$eventId]);
            $event = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($event && strtotime($event['data']) < strtotime('today')) {
                header('Location: view_event.php?event_id=' . $eventId . '&error=evento_passato');
                exit();
            }

            if ($action === 'subscribe') {
                $stmt = $conn->prepare("SELECT COUNT(*) FROM wce_partecipazione WHERE ID_evento = ? AND ID_utente = ?");
                $stmt->execute([$eventId, $userId]);
                $isParticipating = $stmt->fetchColumn();

                if ($isParticipating) {
                    header('Location: view_event.php?event_id=' . $eventId . '&status=gia_iscritto');
                } else {
                    $stmt = $conn->prepare("INSERT INTO wce_partecipazione (ID_evento, ID_utente) VALUES (?, ?)");
                    $stmt->execute([$eventId, $userId]);

                    header('Location: view_event.php?event_id=' . $eventId . '&status=iscritto');
                }
            } elseif ($action === 'unsubscribe') {
                $stmt = $conn->prepare("DELETE FROM wce_partecipazione WHERE ID_evento = ? AND ID_utente = ?");
                $stmt->execute([$eventId, $userId]);

                header('Location: view_event.php?event_id=' . $eventId . '&status=disiscritto');
            }
        } catch (PDOException $e) {
            $errorMessage = urlencode("Errore del database: " . $e->getMessage());
            header('Location: view_event.php?event_id=' . $eventId . '&error=' . $errorMessage);
        }
    } else {
        header('Location: view_event.php?event_id=' . $eventId . '&error=utente_o_evento_mancante');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['commentText'])) {
        handleComment($conn);
    } elseif (isset($_POST['action'])) {
        handleParticipation($conn);
    }
}

$eventId = $_GET['event_id'] ?? null;
$error = $_GET['error'] ?? null;
$status = $_GET['status'] ?? null;

$eventDetails = null;
$comments = [];
if ($eventId) {
    try {
        $eventDetails = getEventDetails($conn, $eventId);
        $comments = getEventComments($conn, $eventId);
    } catch (PDOException $e) {
        $error = "Errore del database: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Dettagli Evento - Live Events Community</title>
</head>
<body>
    <?php include 'assets/header.php'; ?>

    <div class="container mt-4">
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?php
                if ($error === 'non_autenticato') {
                    echo 'Devi essere loggato per iscriverti a un evento.';
                } elseif ($error === 'db_error') {
                    echo 'Si è verificato un errore nel database. Riprova più tardi.';
                } elseif ($error === 'evento_passato') {
                    echo 'L\'evento è già passato.';
                } elseif ($error === 'commento_vuoto') {
                    echo 'Il commento non può essere vuoto.';
                } else {
                    echo htmlspecialchars(urldecode($error));
                }
                ?>
            </div>
        <?php elseif ($status): ?>
            <div class="alert alert-success">
                <?php
                if ($status === 'gia_iscritto') {
                    echo 'Sei già iscritto a questo evento.';
                } elseif ($status === 'iscritto') {
                    echo 'Ti sei iscritto con successo all\'evento.';
                } elseif ($status === 'disiscritto') {
                    echo 'Ti sei disiscritto con successo dall\'evento.';
                }
                ?>
            </div>
        <?php endif; ?>

        <div class="card mb-3">
            <div class="card-body">
                <?php
                if ($eventDetails) {
                    echo '<h5 class="card-title">' . htmlspecialchars($eventDetails['titolo']) . '</h5>';
                    echo '<p class="card-text"><strong>Indirizzo:</strong> ' . htmlspecialchars($eventDetails['indirizzo']) . '</p>';
                    echo '<p class="card-text">' . htmlspecialchars($eventDetails['descrizione']) . '</p>';
                    echo '<p class="card-text"><strong>Data:</strong> ' . htmlspecialchars($eventDetails['data']) . '</p>';
                    echo '<p class="card-text"><strong>Luogo:</strong> ' . htmlspecialchars($eventDetails['luogo_nome']) . '</p>';
                    echo '<p class="card-text"><strong>Categoria:</strong> ' . htmlspecialchars($eventDetails['categoria_nome']) . '</p>';
                } else {
                    echo '<p class="text-danger">Nessun evento selezionato.</p>';
                }
                ?>
            </div>
        </div>

        <div class="mt-4">
            <a href="index.php" class="btn btn-secondary">Torna agli Eventi</a>
            <?php
            $isSubscribed = false;
            $isPastEvent = false;
            if ($eventId && isset($_SESSION['user'])) {
                $userId = $_SESSION['user']['ID_user'];
                $stmt = $conn->prepare("SELECT COUNT(*) FROM wce_partecipazione WHERE ID_evento = ? AND ID_utente = ?");
                $stmt->execute([$eventId, $userId]);
                $isSubscribed = $stmt->fetchColumn() > 0;

                $stmt = $conn->prepare("SELECT data FROM wce_eventi WHERE ID_evento = ?");
                $stmt->execute([$eventId]);
                $eventDate = $stmt->fetchColumn();
                $isPastEvent = strtotime($eventDate) < strtotime('today');
            }

            if ($isSubscribed) {
                echo '<form method="POST" action="view_event.php" style="display:inline;">
                        <input type="hidden" name="event_id" value="' . htmlspecialchars($eventId) . '">
                        <input type="hidden" name="action" value="unsubscribe">
                        <button type="submit" class="btn btn-warning" ' . ($isPastEvent ? 'disabled' : '') . '>Disiscriviti dall\'Evento</button>
                      </form>';
            } else {
                echo '<form method="POST" action="view_event.php" style="display:inline;">
                        <input type="hidden" name="event_id" value="' . htmlspecialchars($eventId) . '">
                        <input type="hidden" name="action" value="subscribe">
                        <button type="submit" class="btn btn-primary">Iscriviti all\'Evento</button>
                      </form>';
            }
            ?>
        </div>

        <div id="commentsSection" style="margin-top: 20px;">
            <form id="commentForm" method="POST" action="view_event.php">
                <input type="hidden" name="event_id" id="event_id" value="<?php echo htmlspecialchars($eventId); ?>">
                <div class="form-group">
                    <label for="commentText">Aggiungi un Commento</label>
                    <textarea class="form-control" id="commentText" name="commentText" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Invia Commento</button>
            </form>

            <h4 style="margin-top: 30px;">Commenti</h4>
            <div class="comments-list" style="margin-top: 20px;">
                <?php
                if ($comments) {
                    foreach ($comments as $comment) {
                        echo '<div class="comment" style="margin-bottom: 40px;">';
                        echo '<p style="font-size: 1.1rem;"><strong>' . htmlspecialchars($comment['nickname']) . '</strong></p>';
                        echo '<p style="margin-top: 2px; font-size: 1rem;">' . htmlspecialchars($comment['testo']) . '</p>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>Nessun commento disponibile.</p>';
                }
                ?>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
