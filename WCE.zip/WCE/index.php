<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

if (!$conn) {
    die("Database connection failed.");
}

function getEvents($conn) {
    $stmt = $conn->prepare("SELECT wce_eventi.*, wce_luogo.nome AS luogo_nome, wce_categoria.nome_cat AS categoria_nome 
                            FROM wce_eventi 
                            JOIN wce_luogo ON wce_eventi.ID_luogo = wce_luogo.ID_luogo 
                            JOIN wce_categoria ON wce_eventi.ID_categoria = wce_categoria.ID_categoria");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getParticipantsCount($conn, $eventId) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM wce_partecipazione WHERE ID_evento = ?");
    $stmt->execute([$eventId]);
    $participants = $stmt->fetch(PDO::FETCH_ASSOC);
    return $participants['count'] ?? 0;
}

function getLocations($conn) {
    $stmt = $conn->prepare("SELECT ID_luogo, nome, sigla FROM wce_luogo");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getCategories($conn) {
    $stmt = $conn->prepare("SELECT ID_categoria, nome_cat FROM wce_categoria");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$userProvince = $_SESSION['user']['residenza'] ?? null;

try {
    $events = getEvents($conn);
    foreach ($events as &$event) {
        if ($event['approvazione'] == true) {
            $event['participants'] = getParticipantsCount($conn, $event['ID_evento']);
        }
    }
    unset($event);

    $events = array_filter($events, function($event) {
        return strtotime($event['data']) >= strtotime('today') && $event['approvazione'] == true;
    });

    usort($events, function($a, $b) {
        return $b['participants'] <=> $a['participants'];
    });

    $provinceEvents = array_filter($events, function($event) use ($userProvince) {
        return $event && $event['ID_luogo'] == $userProvince;
    });

    $locations = getLocations($conn);
    $categories = getCategories($conn);
} catch (PDOException $e) {
    $error = "Query del database fallita: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Live Events Community</title>
    <style>
        .slider-container {
            background-color: #f8f9fa !important;
            padding: 40px !important;
            border-radius: 10px !important;
            margin-bottom: 20px !important;
            border: 2px solid #007bff !important;
            text-align: center !important;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1) !important;
        }
        .carousel-control-prev, .carousel-control-next {
            width: 5% !important;
        }
        .carousel-control-prev-icon, .carousel-control-next-icon {
            background-color: #000 !important;
            border-radius: 50% !important;
            padding: 10px !important;
        }
        .carousel-item {
            text-align: center !important;
        }
        .carousel-item .card {
            display: inline-block !important;
            width: 80% !important;
            margin: auto !important;
            text-align: center !important;
            color: #000 !important;
            border-radius: 10px !important;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1) !important;
            background-color: #f8f9fa !important;
        }
        .carousel-item .card-body {
            text-align: center !important;
        }
        .carousel-indicators li {
            background-color: #6c757d !important;
        }
        .form-inline .form-group {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <?php include 'assets/header.php'; ?>
    
    <div class="container mt-4">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <div class="slider-container">
            <h2>Eventi nella tua zona</h2>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <?php
                    if (!empty($provinceEvents)) {
                        $first = true;
                        foreach ($provinceEvents as $event) {
                            echo '<div class="carousel-item ' . ($first ? 'active' : '') . '">';
                            echo '<div class="card">';
                            echo '<div class="card-body">';
                            echo '<h5 class="card-title">' . htmlspecialchars($event['titolo']) . '</h5>';
                            echo '<p class="card-text">Location: ' . htmlspecialchars($event['luogo_nome']) . '</p>';
                            echo '<p class="card-text">Category: ' . htmlspecialchars($event['categoria_nome']) . '</p>';
                            echo '<p class="card-text">Date: ' . htmlspecialchars($event['data']) . '</p>';
                            echo '<p class="card-text">Participants: ' . htmlspecialchars($event['participants']) . '</p>';
                            echo '<a href="view_event.php?event_id=' . htmlspecialchars($event['ID_evento']) . '" class="btn btn-primary">View Event</a>';
                            echo '</div></div></div>';
                            $first = false;
                        }
                    } else {
                        echo '<div class="carousel-item active">';
                        echo '<p>No events available in your province at this time.</p>';
                        echo '</div>';
                    }
                    ?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>

        <div class="cards-container">
            <h2>Our Events</h2>
            <div class="form-inline">
                <div class="form-group">
                    <label for="sortCriteria1">Sort by:</label>
                    <select class="form-control ml-2" id="sortCriteria1">
                        <option value="participants">Participants</option>
                        <option value="date">Date</option>
                        <option value="location">Location</option>
                        <option value="category">Category</option>
                    </select>
                </div>
                <div class="form-group" id="dateFilter1" style="display: none;">
                    <label for="dateFrom1">Select Date From:</label>
                    <input type="date" class="form-control ml-2" id="dateFrom1">
                </div>
                <div class="form-group" id="locationFilter1" style="display: none;">
                    <label for="locationSelect1">Select Location:</label>
                    <select class="form-control ml-2" id="locationSelect1">
                        <option value="">All Locations</option>
                        <?php
                        if (is_array($locations) && !empty($locations)) {
                            foreach ($locations as $location) {
                                echo '<option value="' . htmlspecialchars($location['nome']) . '">' . htmlspecialchars($location['nome']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group" id="categoryFilter1" style="display: none;">
                    <label for="categorySelect1">Select Category:</label>
                    <select class="form-control ml-2" id="categorySelect1">
                        <option value="">All Categories</option>
                        <?php
                        if (is_array($categories) && !empty($categories)) {
                            foreach ($categories as $category) {
                                echo '<option value="' . htmlspecialchars($category['nome_cat']) . '">' . htmlspecialchars($category['nome_cat']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-inline mt-3" id="criteria2Container" style="display: none;">
                <div class="form-group">
                    <label for="sortCriteria2">Then by:</label>
                    <select class="form-control ml-2" id="sortCriteria2">
                        <option value="">None</option>
                        <option value="participants">Participants</option>
                        <option value="date">Date</option>
                        <option value="location">Location</option>
                        <option value="category">Category</option>
                    </select>
                </div>
                <div class="form-group" id="dateFilter2" style="display: none;">
                    <label for="dateFrom2">Select Date From:</label>
                    <input type="date" class="form-control ml-2" id="dateFrom2">
                </div>
                <div class="form-group" id="locationFilter2" style="display: none;">
                    <label for="locationSelect2">Select Location:</label>
                    <select class="form-control ml-2" id="locationSelect2">
                        <option value="">All Locations</option>
                        <?php
                        if (is_array($locations) && !empty($locations)) {
                            foreach ($locations as $location) {
                                echo '<option value="' . htmlspecialchars($location['nome']) . '">' . htmlspecialchars($location['nome']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group" id="categoryFilter2" style="display: none;">
                    <label for="categorySelect2">Select Category:</label>
                    <select class="form-control ml-2" id="categorySelect2">
                        <option value="">All Categories</option>
                        <?php
                        if (is_array($categories) && !empty($categories)) {
                            foreach ($categories as $category) {
                                echo '<option value="' . htmlspecialchars($category['nome_cat']) . '">' . htmlspecialchars($category['nome_cat']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-inline mt-3" id="criteria3Container" style="display: none;">
                <div class="form-group">
                    <label for="sortCriteria3">Then by:</label>
                    <select class="form-control ml-2" id="sortCriteria3">
                        <option value="">None</option>
                        <option value="participants">Participants</option>
                        <option value="date">Date</option>
                        <option value="location">Location</option>
                        <option value="category">Category</option>
                    </select>
                </div>
                <div class="form-group" id="dateFilter3" style="display: none;">
                    <label for="dateFrom3">Select Date From:</label>
                    <input type="date" class="form-control ml-2" id="dateFrom3">
                </div>
                <div class="form-group" id="locationFilter3" style="display: none;">
                    <label for="locationSelect3">Select Location:</label>
                    <select class="form-control ml-2" id="locationSelect3">
                        <option value="">All Locations</option>
                        <?php
                        if (is_array($locations) && !empty($locations)) {
                            foreach ($locations as $location) {
                                echo '<option value="' . htmlspecialchars($location['nome']) . '">' . htmlspecialchars($location['nome']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group" id="categoryFilter3" style="display: none;">
                    <label for="categorySelect3">Select Category:</label>
                    <select class="form-control ml-2" id="categorySelect3">
                        <option value="">All Categories</option>
                        <?php
                        if (is_array($categories) && !empty($categories)) {
                            foreach ($categories as $category) {
                                echo '<option value="' . htmlspecialchars($category['nome_cat']) . '">' . htmlspecialchars($category['nome_cat']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-inline mt-3" id="criteria4Container" style="display: none;">
                <div class="form-group">
                    <label for="sortCriteria4">Then by:</label>
                    <select class="form-control ml-2" id="sortCriteria4">
                        <option value="">None</option>
                        <option value="participants">Participants</option>
                        <option value="date">Date</option>
                        <option value="location">Location</option>
                        <option value="category">Category</option>
                    </select>
                </div>
                <div class="form-group" id="dateFilter4" style="display: none;">
                    <label for="dateFrom4">Select Date From:</label>
                    <input type="date" class="form-control ml-2" id="dateFrom4">
                </div>
                <div class="form-group" id="locationFilter4" style="display: none;">
                    <label for="locationSelect4">Select Location:</label>
                    <select class="form-control ml-2" id="locationSelect4">
                        <option value="">All Locations</option>
                        <?php
                        if (is_array($locations) && !empty($locations)) {
                            foreach ($locations as $location) {
                                echo '<option value="' . htmlspecialchars($location['nome']) . '">' . htmlspecialchars($location['nome']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group" id="categoryFilter4" style="display: none;">
                    <label for="categorySelect4">Select Category:</label>
                    <select class="form-control ml-2" id="categorySelect4">
                        <option value="">All Categories</option>
                        <?php
                        if (is_array($categories) && !empty($categories)) {
                            foreach ($categories as $category) {
                                echo '<option value="' . htmlspecialchars($category['nome_cat']) . '">' . htmlspecialchars($category['nome_cat']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="row mt-3" id="eventsContainer">
                <?php
                if (is_array($events) && !empty($events)) {
                    foreach ($events as $event) {
                        echo '<div class="col-md-4 event-card" data-participants="' . htmlspecialchars($event['participants']) . '" data-date="' . htmlspecialchars($event['data']) . '" data-location="' . htmlspecialchars($event['luogo_nome']) . '" data-category="' . htmlspecialchars($event['categoria_nome']) . '">';
                        echo '<div class="card mb-3">';
                        echo '<div class="card-body">';
                        echo '<h5 class="card-title">' . htmlspecialchars($event['titolo']) . '</h5>';
                        echo '<p class="card-text">Location: ' . htmlspecialchars($event['luogo_nome']) . '</p>';
                        echo '<p class="card-text">Category: ' . htmlspecialchars($event['categoria_nome']) . '</p>';
                        echo '<p class="card-text">Date: ' . htmlspecialchars($event['data']) . '</p>';
                        echo '<p class="card-text">Participants: ' . htmlspecialchars($event['participants']) . '</p>';
                        echo '<a href="view_event.php?event_id=' . htmlspecialchars($event['ID_evento']) . '" class="btn btn-primary">View Event</a>';
                        echo '</div></div></div>';
                    }
                } else {
                    echo '<p>No events available at this time.</p>';
                }
                ?>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://stackpath.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="assets/script.js"></script>
</body>
</html>
