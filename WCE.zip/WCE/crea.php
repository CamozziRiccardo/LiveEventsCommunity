<?php
require_once 'db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

//get categories
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $conn->prepare("SELECT ID_categoria, nome_cat FROM wce_categoria");
        $stmt->execute();
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = json_encode(["error" => "Query del database fallita: " . $e->getMessage()]);
    }
}

//get locations
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $conn->prepare("SELECT ID_luogo, nome, sigla FROM wce_luogo");
        $stmt->execute();
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = json_encode(["error" => "Query del database fallita: " . $e->getMessage()]);
    }
}

//create new event
function postEvent($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_SESSION['user'])) {
            $error = json_encode(["error" => "Utente non autorizzato"]);
            exit();
        }

        $category = $_POST['category'] ?? null;
        $location = $_POST['location'] ?? null;
        $userId = $_SESSION['user']['ID_user'] ?? null;
        $eventName = $_POST['eventName'] ?? null;
        $eventDate = $_POST['eventDate'] ?? null;
        $eventAddress = $_POST['eventAddress'] ?? null;
        $eventDescription = $_POST['eventDescription'] ?? null;

        if ($category && $location && $userId && $eventName && $eventDate && $eventDescription) {
            try {
                $stmt = $conn->prepare("INSERT INTO wce_eventi (ID_categoria, ID_luogo, ID_user, titolo, data, indirizzo, descrizione, approvazione) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$category, $location, $userId, $eventName, $eventDate, $eventAddress, $eventDescription, false]);

                $status = 'successo';
                header("Location: crea.php");
                exit();
            } catch (PDOException $e) {
                $error = json_encode('Errore del database: ' . $e->getMessage());
                return;
            }
        } else {
            $error = json_encode(["error" => "Campi mancanti"]);
            return;
        }
    } else {
        $error = json_encode(["error" => "Richiesta non valida"]);
        return;
    }
}

// chiamata funzione se si richiede una post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    postEvent($conn);
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Crea Evento - Live Events Community</title>
</head>
<body>
    <?php include 'assets/header.php'; ?>

    <div class="container mt-4">
        <h2>Crea un Nuovo Evento</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo ($error); ?>
            </div>
        <?php elseif (isset($status)): ?>
            <div class="alert alert-success">
                Evento creato con successo.
            </div>
        <?php endif; ?>

        <form action="crea.php" method="POST">
            <div class="form-group">
                <label for="category">Categoria</label>
                <select class="form-control" id="category" name="category" required>
                    <option value="">Seleziona Categoria</option>
                    <?php
                    if (is_array($categories) && !empty($categories)) {
                        foreach ($categories as $category) {
                            echo '<option value="' . htmlspecialchars($category['ID_categoria']) . '">' . htmlspecialchars($category['nome_cat']) . '</option>';
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="location">Luogo</label>
                <select class="form-control" id="location" name="location" required>
                    <option value="">Seleziona Luogo</option>
                    <?php
                    if (is_array($locations) && !empty($locations)) {
                        foreach ($locations as $location) {
                            echo '<option value="' . htmlspecialchars($location['ID_luogo']) . '">' . htmlspecialchars($location['nome']) . '</option>';
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="eventName">Nome Evento</label>
                <input type="text" class="form-control" id="eventName" name="eventName" required>
            </div>
            <div class="form-group">
                <label for="eventDate">Data Evento</label>
                <input type="date" class="form-control" id="eventDate" name="eventDate" required>
            </div>
            <div class="form-group">
                <label for="eventAddress">Indirizzo Evento</label>
                <input type="text" class="form-control" id="eventAddress" name="eventAddress" required>
            </div>
            <div class="form-group">
                <label for="eventDescription">Descrizione Evento</label>
                <textarea class="form-control" id="eventDescription" name="eventDescription" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Crea Evento</button>
        </form>
    </div>

</body>
</html>
