<?php
session_start();

function handleLogin($conn) {
    $email = $_POST['email'] ?? null;
    $password = $_POST['password'] ?? null;

    if ($email && $password) {
        try {
            $stmt = $conn->prepare("SELECT * FROM wce_utenti WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user'] = $user;
                if ($user['ID_user'] == 1) {
                    header("Location: special.php");
                } else {
                    header("Location: index.php");
                }
                exit();
            } else {
                header("Location: login.php?error=credenziali_non_valide");
                exit();
            }
        } catch (PDOException $e) {
            header("Location: login.php?error=errore_db");
            exit();
        }
    } else {
        header("Location: login.php?error=campi_mancanti");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require 'db.php';
    handleLogin($conn);
}

$error = $_GET['error'] ?? null;
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Accedi - Live Events Community</title>
</head>
<body>
    <?php include 'assets/header.php'; ?>

    <div class="container mt-4">
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?php
                if ($error === 'credenziali_non_valide') {
                    echo 'Email o password non validi.';
                } elseif ($error === 'campi_mancanti') {
                    echo 'Per favore, compila tutti i campi.';
                } elseif ($error === 'errore_db') {
                    echo 'Si è verificato un errore nel database. Riprova più tardi.';
                } else {
                    echo htmlspecialchars(urldecode($error));
                }
                ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Accedi</h5>
                <form method="POST" action="login.php">
                    <div class="form-group">
                        <label for="email">Indirizzo email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="password" name="password" required>
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                    <i class="fa fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Accedi</button>
                </form>
                <p class="mt-3">Non sei registrato? <a href="register.php">Registrati qui</a></p>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.getElementById('togglePassword').addEventListener('click', function () {
            var passwordField = document.getElementById('password');
            var passwordFieldType = passwordField.getAttribute('type');
            if (passwordFieldType === 'password') {
                passwordField.setAttribute('type', 'text');
                this.innerHTML = '<i class="fa fa-eye-slash"></i>';
            } else {
                passwordField.setAttribute('type', 'password');
                this.innerHTML = '<i class="fa fa-eye"></i>';
            }
        });
    </script>
</body>
</html>
