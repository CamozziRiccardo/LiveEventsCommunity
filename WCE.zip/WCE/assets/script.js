$(document).ready(function(){
    $('#carouselExampleIndicators').carousel({
        interval: 2000
    });

    function handleSortCriteriaChange(criteria, dateFilter, locationFilter, categoryFilter, nextCriteria) {
        if (criteria === 'date') {
            $(dateFilter).show();
            $(locationFilter).hide();
            $(categoryFilter).hide();
        } else if (criteria === 'location') {
            $(locationFilter).show();
            $(dateFilter).hide();
            $(categoryFilter).hide();
        } else if (criteria === 'category') {
            $(categoryFilter).show();
            $(dateFilter).hide();
            $(locationFilter).hide();
        } else {
            $(dateFilter).hide();
            $(locationFilter).hide();
            $(categoryFilter).hide();
        }

        if (criteria === '') {
            $(nextCriteria).hide();
        } else {
            $(nextCriteria).show();
        }
    }

    function updateDropdownOptions() {
        var selectedCriteria1 = $('#sortCriteria1').val();
        var selectedCriteria2 = $('#sortCriteria2').val();
        var selectedCriteria3 = $('#sortCriteria3').val();

        $('#sortCriteria2 option').show();
        $('#sortCriteria3 option').show();
        $('#sortCriteria4 option').show();

        if (selectedCriteria1) {
            $('#sortCriteria2 option[value="' + selectedCriteria1 + '"]').hide();
            $('#sortCriteria3 option[value="' + selectedCriteria1 + '"]').hide();
            $('#sortCriteria4 option[value="' + selectedCriteria1 + '"]').hide();
        }
        if (selectedCriteria2) {
            $('#sortCriteria3 option[value="' + selectedCriteria2 + '"]').hide();
            $('#sortCriteria4 option[value="' + selectedCriteria2 + '"]').hide();
        }
        if (selectedCriteria3) {
            $('#sortCriteria4 option[value="' + selectedCriteria3 + '"]').hide();
        }
    }

    $('#sortCriteria1').change(function() {
        var criteria = $(this).val();
        handleSortCriteriaChange(criteria, '#dateFilter1', '#locationFilter1', '#categoryFilter1', '#criteria2Container');
        updateDropdownOptions();
        sortEvents();
    });

    $('#sortCriteria2').change(function() {
        var criteria = $(this).val();
        handleSortCriteriaChange(criteria, '#dateFilter2', '#locationFilter2', '#categoryFilter2', '#criteria3Container');
        updateDropdownOptions();
        sortEvents();
    });

    $('#sortCriteria3').change(function() {
        var criteria = $(this).val();
        handleSortCriteriaChange(criteria, '#dateFilter3', '#locationFilter3', '#categoryFilter3', '#criteria4Container');
        updateDropdownOptions();
        sortEvents();
    });

    $('#sortCriteria4').change(function() {
        var criteria = $(this).val();
        handleSortCriteriaChange(criteria, '#dateFilter4', '#locationFilter4', '#categoryFilter4', '');
        updateDropdownOptions();
        sortEvents();
    });

    $('#dateFrom1, #dateFrom2, #dateFrom3, #dateFrom4').change(function() {
        sortEvents();
    });

    $('#locationSelect1, #locationSelect2, #locationSelect3, #locationSelect4').change(function() {
        sortEvents();
    });

    $('#categorySelect1, #categorySelect2, #categorySelect3, #categorySelect4').change(function() {
        sortEvents();
    });

    function sortEvents() {
        var criteria1 = $('#sortCriteria1').val();
        var criteria2 = $('#sortCriteria2').val();
        var criteria3 = $('#sortCriteria3').val();
        var criteria4 = $('#sortCriteria4').val();
        var $eventsContainer = $('#eventsContainer');
        var $events = $eventsContainer.children('.event-card');

        $events.sort(function(a, b) {
            var aValue1 = $(a).data(criteria1);
            var bValue1 = $(b).data(criteria1);
            var aValue2 = $(a).data(criteria2);
            var bValue2 = $(b).data(criteria2);
            var aValue3 = $(a).data(criteria3);
            var bValue3 = $(b).data(criteria3);
            var aValue4 = $(a).data(criteria4);
            var bValue4 = $(b).data(criteria4);

            if (criteria1 === 'participants') {
                if (bValue1 !== aValue1) return bValue1 - aValue1;
            } else if (criteria1 === 'date') {
                if (new Date(aValue1) !== new Date(bValue1)) return new Date(aValue1) - new Date(bValue1);
            } else {
                if (aValue1 !== bValue1) return aValue1.localeCompare(bValue1);
            }

            if (criteria2 === 'participants') {
                if (bValue2 !== aValue2) return bValue2 - aValue2;
            } else if (criteria2 === 'date') {
                if (new Date(aValue2) !== new Date(bValue2)) return new Date(aValue2) - new Date(bValue2);
            } else {
                if (aValue2 !== bValue2) return aValue2.localeCompare(bValue2);
            }

            if (criteria3 === 'participants') {
                if (bValue3 !== aValue3) return bValue3 - aValue3;
            } else if (criteria3 === 'date') {
                if (new Date(aValue3) !== new Date(bValue3)) return new Date(aValue3) - new Date(bValue3);
            } else {
                if (aValue3 !== bValue3) return aValue3.localeCompare(bValue3);
            }

            if (criteria4 === 'participants') {
                return bValue4 - aValue4;
            } else if (criteria4 === 'date') {
                return new Date(aValue4) - new Date(bValue4);
            } else {
                return aValue4.localeCompare(bValue4);
            }
        });

        $eventsContainer.html($events);
    }
});