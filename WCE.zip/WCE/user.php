<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Informazioni Utente - Live Events Community</title>
</head>
<body>
    <?php 
    session_start();
    require 'db.php';
    include 'assets/header.php'; 

    function getUserEvents($conn, $userId, $future = true) {
        $dateCondition = $future ? '>= CURDATE()' : '< CURDATE()';
        $stmt = $conn->prepare("SELECT wce_eventi.titolo, wce_eventi.data, wce_eventi.ID_evento 
                                FROM wce_partecipazione 
                                JOIN wce_eventi ON wce_partecipazione.ID_evento = wce_eventi.ID_evento 
                                WHERE wce_partecipazione.ID_utente = ? AND wce_eventi.data $dateCondition");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function handleParticipation($conn) {
        if (!isset($_SESSION['user'])) {
            header('Location: user.php?error=non_autenticato');
            exit();
        }

        $userId = $_SESSION['user']['ID_user'] ?? null;
        $eventId = $_POST['event_id'] ?? null;
        $action = $_POST['action'] ?? null;

        if ($userId && $eventId) {
            try {
                $stmt = $conn->prepare("SELECT data FROM wce_eventi WHERE ID_evento = ?");
                $stmt->execute([$eventId]);
                $event = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($event && strtotime($event['data']) < strtotime('today')) {
                    header('Location: user.php?error=evento_passato');
                    exit();
                }

                if ($action === 'subscribe') {
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM wce_partecipazione WHERE ID_evento = ? AND ID_utente = ?");
                    $stmt->execute([$eventId, $userId]);
                    $isParticipating = $stmt->fetchColumn();

                    if ($isParticipating) {
                        header('Location: user.php?status=gia_iscritto');
                    } else {
                        $stmt = $conn->prepare("INSERT INTO wce_partecipazione (ID_evento, ID_utente) VALUES (?, ?)");
                        $stmt->execute([$eventId, $userId]);

                        header('Location: user.php?status=iscritto');
                    }
                } elseif ($action === 'unsubscribe') {
                    $stmt = $conn->prepare("DELETE FROM wce_partecipazione WHERE ID_evento = ? AND ID_utente = ?");
                    $stmt->execute([$eventId, $userId]);

                    header('Location: user.php?status=disiscritto');
                }
            } catch (PDOException $e) {
                $errorMessage = urlencode("Errore del database: " . $e->getMessage());
                header('Location: user.php?error=' . $errorMessage);
            }
        } else {
            header('Location: user.php?error=utente_o_evento_mancante');
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        handleParticipation($conn);
    }
    ?>
    
    <div class="container mt-4">
        <h2>Informazioni Utente</h2>
        <?php if (isset($_SESSION['user'])): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Dettagli Utente</h5>
                    <p><strong>Nome:</strong> <?php echo htmlspecialchars($_SESSION['user']['nome']); ?></p>
                    <p><strong>Cognome:</strong> <?php echo htmlspecialchars($_SESSION['user']['cognome']); ?></p>
                    <p><strong>Nickname:</strong> <?php echo htmlspecialchars($_SESSION['user']['nickname']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['user']['email']); ?></p>
                </div>
            </div>
            <form action="logout.php" method="post" style="display:inline;">
                <button type="submit" class="btn btn-danger">Logout</button>
            </form>
            <a href="index.php" class="btn btn-secondary ml-2">Home</a>

            <div class="row mt-4">
                <div class="col-md-6">
                    <h3>Eventi Futuri</h3>
                    <div class="list-group">
                        <?php
                        $userId = $_SESSION['user']['ID_user'];
                        try {
                            $futureEvents = getUserEvents($conn, $userId, true);

                            if ($futureEvents) {
                                foreach ($futureEvents as $event) {
                                    echo '<div class="list-group-item">';
                                    echo '<h5 class="mb-1">' . htmlspecialchars($event['titolo']) . '</h5>';
                                    echo '<p class="mb-1"><strong>Data:</strong> ' . htmlspecialchars($event['data']) . '</p>';
                                    echo '<a href="view_event.php?event_id=' . htmlspecialchars($event['ID_evento']) . '" class="btn btn-info mt-2">Visualizza Evento Completo</a>';
                                    echo '<form method="POST" action="user.php" style="display:inline;">
                                            <input type="hidden" name="event_id" value="' . htmlspecialchars($event['ID_evento']) . '">
                                            <input type="hidden" name="action" value="unsubscribe">
                                            <button type="submit" class="btn btn-warning mt-2">Disiscriviti</button>
                                          </form>';
                                    echo '</div>';
                                }
                            } else {
                                echo '<p class="text-muted">Non sei iscritto a nessun evento futuro.</p>';
                            }
                        } catch (PDOException $e) {
                            echo '<div class="alert alert-danger">Errore nel recupero degli eventi futuri: ' . htmlspecialchars($e->getMessage()) . '</div>';
                        }
                        ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <h3>Eventi Passati</h3>
                    <div class="list-group">
                        <?php
                        try {
                            $pastEvents = getUserEvents($conn, $userId, false);

                            if ($pastEvents) {
                                foreach ($pastEvents as $event) {
                                    echo '<div class="list-group-item">';
                                    echo '<h5 class="mb-1">' . htmlspecialchars($event['titolo']) . '</h5>';
                                    echo '<p class="mb-1"><strong>Data:</strong> ' . htmlspecialchars($event['data']) . '</p>';
                                    echo '<a href="view_event.php?event_id=' . htmlspecialchars($event['ID_evento']) . '" class="btn btn-info mt-2">Visualizza Evento Completo</a>';
                                    echo '</div>';
                                }
                            } else {
                                echo '<p class="text-muted">Non hai partecipato a nessun evento passato.</p>';
                            }
                        } catch (PDOException $e) {
                            echo '<div class="alert alert-danger">Errore nel recupero degli eventi passati: ' . htmlspecialchars($e->getMessage()) . '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <p class="text-danger">Nessuna informazione utente disponibile. Per favore, accedi.</p>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
